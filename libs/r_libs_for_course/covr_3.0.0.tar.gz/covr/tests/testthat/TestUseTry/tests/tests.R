TestUseTry::fun()
