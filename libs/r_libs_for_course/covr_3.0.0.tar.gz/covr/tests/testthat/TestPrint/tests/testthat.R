library(testthat)
library("TestPrint")

test_check("TestPrint")
